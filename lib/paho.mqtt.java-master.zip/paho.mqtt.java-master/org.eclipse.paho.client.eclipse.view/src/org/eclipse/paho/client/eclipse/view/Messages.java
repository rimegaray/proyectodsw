package org.eclipse.paho.client.eclipse.view;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "org.eclipse.paho.client.eclipse.view.messages"; //$NON-NLS-1$
	public static String MqttClientView_10;
	public static String MqttClientView_100;
	public static String MqttClientView_101;
	public static String MqttClientView_102;
	public static String MqttClientView_103;
	public static String MqttClientView_104;
	public static String MqttClientView_105;
	public static String MqttClientView_106;
	public static String MqttClientView_11;
	public static String MqttClientView_12;
	public static String MqttClientView_110;
	public static String MqttClientView_111;
	public static String MqttClientView_15;
	public static String MqttClientView_16;
	public static String MqttClientView_17;
	public static String MqttClientView_19;
	public static String MqttClientView_20;
	public static String MqttClientView_21;
	public static String MqttClientView_22;
	public static String MqttClientView_23;
	public static String MqttClientView_24;
	public static String MqttClientView_25;
	public static String MqttClientView_26;
	public static String MqttClientView_28;
	public static String MqttClientView_29;
	public static String MqttClientView_30;
	public static String MqttClientView_32;
	public static String MqttClientView_34;
	public static String MqttClientView_36;
	public static String MqttClientView_38;
	public static String MqttClientView_39;
	public static String MqttClientView_41;
	public static String MqttClientView_42;
	public static String MqttClientView_43;
	public static String MqttClientView_45;
	public static String MqttClientView_47;
	public static String MqttClientView_48;
	public static String MqttClientView_49;
	public static String MqttClientView_50;
	public static String MqttClientView_51;
	public static String MqttClientView_52;
	public static String MqttClientView_54;
	public static String MqttClientView_56;
	public static String MqttClientView_6;
	public static String MqttClientView_62;
	public static String MqttClientView_63;
	public static String MqttClientView_64;
	public static String MqttClientView_65;
	public static String MqttClientView_66;
	public static String MqttClientView_67;
	public static String MqttClientView_68;
	public static String MqttClientView_69;
	public static String MqttClientView_7;
	public static String MqttClientView_70;
	public static String MqttClientView_71;
	public static String MqttClientView_72;
	public static String MqttClientView_73;
	public static String MqttClientView_74;
	public static String MqttClientView_75;
	public static String MqttClientView_76;
	public static String MqttClientView_77;
	public static String MqttClientView_78;
	public static String MqttClientView_79;
	public static String MqttClientView_8;
	public static String MqttClientView_80;
	public static String MqttClientView_81;
	public static String MqttClientView_82;
	public static String MqttClientView_83;
	public static String MqttClientView_87;
	public static String MqttClientView_88;
	public static String MqttClientView_89;
	public static String MqttClientView_9;
	public static String MqttClientView_90;
	public static String MqttClientView_91;
	public static String MqttClientView_92;
	public static String MqttClientView_93;
	public static String MqttClientView_94;
	public static String MqttClientView_95;
	public static String MqttClientView_96;
	public static String MqttClientView_97;
	public static String MqttClientView_99;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
